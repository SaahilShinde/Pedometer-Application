package com.example.footstep2
import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity(), SensorEventListener {

    private var sensorManager: SensorManager? = null
    private var running = false
    private var totalSteps = 0f
    val ACTIVITY_RECOGNITION_REQUEST_CODE = 100

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        if (isPermissionGranted()) {
            requestPermission()
        }

        sensorManager = getSystemService(Context.SENSOR_SERVICE) as SensorManager

        val bt2 = findViewById<Button>(R.id.btn2)
        bt2.setOnClickListener {
            Toast.makeText(this, "Tracking Stopped", Toast.LENGTH_SHORT).show()
            running = false
            sensorManager?.unregisterListener(this)
        }
    }

    private fun requestPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q)
        {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.ACTIVITY_RECOGNITION), ACTIVITY_RECOGNITION_REQUEST_CODE)
        }
    }

    private fun isPermissionGranted(): Boolean {
        return ContextCompat.checkSelfPermission(this, Manifest.permission.ACTIVITY_RECOGNITION) != PackageManager.PERMISSION_GRANTED
    }

    override fun onResume() {
        super.onResume()
        var bt1 = findViewById<Button>(R.id.btn1)
        bt1.setOnClickListener {
            Toast.makeText(this, "Tracking Started", Toast.LENGTH_SHORT).show()
            running = true
            val stepSensor = sensorManager?.getDefaultSensor(Sensor.TYPE_STEP_COUNTER)

            if (stepSensor == null) {
                Toast.makeText(this, "No sensor detected on this device", Toast.LENGTH_SHORT).show()
            } else {
                sensorManager?.registerListener(this, stepSensor, SensorManager.SENSOR_DELAY_FASTEST)
            }
        }
    }

    override fun onPause() {
        super.onPause()
            running = false
            sensorManager?.unregisterListener(this)
    }

    override fun onSensorChanged(event: SensorEvent?) {
        var tv_stepsTaken = findViewById<TextView>(R.id.stepcount)
        var calories = findViewById<TextView>(R.id.calocount)

        if (running)
        {
            totalSteps = event!!.values[0]

            val currentSteps = totalSteps.toInt()
            tv_stepsTaken.text = ("$currentSteps")

            var s=currentSteps/25
            calories.text = ("$s")
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int)
    {
        println("onAccuracyChanged: Sensor: $sensor; accuracy: $accuracy")
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray)
    {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        when (requestCode) {
            ACTIVITY_RECOGNITION_REQUEST_CODE -> {
                if ((grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED))
                {
                    // Permission is granted, Continue the action or workflow
                }
            }
        }
    }
}